// JavaScript Document
var fullScreenPlay = true;
var client = document.getElementById('client');
var adid = client.getAttribute("adid");
if (!adid)
    adid = "";
if (!getCookie('temp_adv_full' + adid)) {
    var date = new Date();
    //date.setTime(date.getTime() + 30 * 60 * 1000);
    date.setTime(date.getTime() + 4 * 60 * 60 * 1000);
    document.cookie = 'temp_adv_full' + adid + '=' + escape('3gnews') + '; expires=' + date.toGMTString() + ';path=/';

    client.innerHTML = newsStr;
    var newsClient = document.getElementById('news-client');
    var newsClose = document.getElementById('fullclose');
    var maskDiv = document.getElementById("mask");
    var closed = false;


    newsClose.onclick = function () {
        newsHid();
        return false;
    }
} else {
    document.body.style.height = 'auto';
    document.body.style.overflow = 'auto';
    document.documentElement.style.height = 'auto';
    document.documentElement.style.overflow = 'auto';
    fullScreenPlay = false;
}

function news_Load() {
    newsAd();
    setTimeout(function () {
        newsHid();
    }, 4000);
}
function newsLoad() {
    newsAd();
    setTimeout(function () {
        newsHid();
    }, 4000);
}
window.onresize = function () {
    if (!closed) {
        var img = newsClient.getElementsByTagName('img')[0];
        if (document.body.clientWidth / document.body.clientHeight > img.clientWidth / img.clientHeight) {
            img.style.width = '';
            img.style.height = '100%';
            img.style.marginLeft = (document.body.clientWidth - img.clientWidth) / 2 + 'px';
            newsClose.style.right = (document.body.clientWidth - img.clientWidth) / 2 + 6 + 'px';
        } else {
            img.style.width = '100%';
            img.style.height = '';
            img.style.marginLeft = '0';
            newsClose.style.right = '6px';
        }
        newsClose.style.bottom = img.clientWidth * 192 / 320 + 'px';
    }
}

function newsAd() {
    document.body.style.height = '100%';
    document.body.style.overflow = 'hidden';
    document.documentElement.style.height = '100%';
    document.documentElement.style.overflow = 'hidden';
    newsClient.style.height = '100%';
    maskDiv.style.display = "block";
    newsClient.style.opacity = 1;
    var img = newsClient.getElementsByTagName('img')[0];
    if (document.body.clientWidth / document.body.clientHeight > img.clientWidth / img.clientHeight) {
        img.style.width = '';
        img.style.height = '100%';
        img.style.marginLeft = (document.body.clientWidth - img.clientWidth) / 2 + 'px';
        newsClose.style.right = (document.body.clientWidth - img.clientWidth) / 2 + 6 + 'px';
    } else {
        img.style.width = '100%';
        img.style.height = '';
    }
    newsClose.style.bottom = img.clientWidth * 192 / 320 + 'px';
}
function newsHid() {
    newsClient.style.opacity = 0;
    maskDiv.setAttribute("style", "display:none");
    setTimeout(function () {
        newsClient.style.height = 0;
        document.body.style.height = 'auto';
        document.body.style.overflow = 'auto';
        document.documentElement.style.height = 'auto';
        document.documentElement.style.overflow = 'auto';
        closed = true;
        fullScreenPlay = false;
    }, 1000);
}
function getCookie(name) {
    var strCookie = document.cookie;
    var arrCookie = strCookie.split('; ');
    for (var i = 0; i < arrCookie.length; i++) {
        var arr = arrCookie[i].split('=');
        if (arr[0] == name) {
            return arr[1];
        }
    }
    return "";
}

var drag_ad_top = document.getElementById("client");
var maskMove = document.getElementById("mask");
var body0 = document.getElementById("body0");
if (body0 && drag_ad_top) {
    drag_ad_top.parentNode.removeChild(drag_ad_top);
    body0.insertBefore(drag_ad_top, body0.firstChild);
    if(maskMove)
    {
        maskMove.parentNode.removeChild(maskMove);
        body0.insertBefore(maskMove, body0.firstChild);
    }
}